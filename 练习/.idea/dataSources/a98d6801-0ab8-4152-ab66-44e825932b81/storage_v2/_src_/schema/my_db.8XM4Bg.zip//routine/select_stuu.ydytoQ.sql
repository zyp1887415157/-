create procedure select_stuu(IN name varchar(255), IN id int)
  begin   
select * from t_students where stu_name = name;     
select * from t_students where stu_id = id;     
end;

