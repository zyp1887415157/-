create procedure query_stu()
  begin  
select * from t_students;   
end;

