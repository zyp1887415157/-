create procedure insert_stu(IN name varchar(255), IN birthday date, IN gender varchar(255), OUT qty int)
  begin   
select qty;  
insert into t_students (stu_name,birthday,stu_gender)   
value (name,birthday,gender);   
set qty = (select row_count());     
end;

