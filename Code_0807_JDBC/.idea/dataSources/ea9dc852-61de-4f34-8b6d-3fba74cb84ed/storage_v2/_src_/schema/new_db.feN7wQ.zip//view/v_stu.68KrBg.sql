create view v_stu as
  select
    `sc`.`stu_id`                                   AS `stu_id`,
    group_concat(`crs`.`course_name` separator ',') AS `courses`
  from (`new_db`.`t_score` `sc` left join `new_db`.`t_courses` `crs` on ((`sc`.`course_id` = `crs`.`course_id`)))
  group by `sc`.`stu_id`;

